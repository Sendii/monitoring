<?php echo $__env->make('layouts.adminlte', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form class="form-horizontal" method="POST" action=" <?php echo e(route('saveBppj')); ?> " >
	<input type="hidden" name="id" value="<?php echo e($pbbjedit->id); ?>">
	<?php echo $__env->make('bppj.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
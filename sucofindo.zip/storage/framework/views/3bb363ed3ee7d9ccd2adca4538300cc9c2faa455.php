<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    
    <!-- Default to the left -->
    <strong>Copyright &copy; 2017 <a href="http://smkn10jakarta.sch.id">Smkn10</a>.</strong> Created by<a href="technosoft7">Technosoft'7</a>. Support by <a href="technosoft">Technosoft</a>
</footer>
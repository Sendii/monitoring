
<table>
	<thead>
		<tr>
			<td>No.</td>
			<td>Cabang</td>
			<td>Unit Kerja</td>
		</tr>
	</thead>
<?php $__currentLoopData = $UnitAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
	<tbody>
		<tr>
			<td><?php echo e($key->id_unit); ?></td>
			<td><?php echo e($key->aa); ?></td>
			<td><?php echo e($key->unit_kerja); ?></td>
		</tr>
	</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
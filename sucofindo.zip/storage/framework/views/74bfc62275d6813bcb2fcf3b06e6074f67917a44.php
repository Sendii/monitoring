<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="content-wrapper">
	<div class="container-fluid spark-screen">
		<div class="col-xs-12"><br>
			<div class="box">
				<div class="box-header">
					<div class="box-body">
						<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>No</th>
									<th>Nama</th>
									<th>Email</th>
									<th>Akses</th>
									<th>Ubah Akses</th>
								</tr>
							</thead>

							<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tbody>
								<tr>
									<td><?php echo e($key->id); ?></td>
									<td><?php echo e($key->name); ?></td>
									<td><?php echo e($key->email); ?></td>
									<td class="center">
										<?php if($key->akses == "Kasubag"): ?>
										<i>Kasubag</i>
										<?php elseif($key->akses == "Admin"): ?>
										<i>Admin</i>
										<?php elseif($key->akses=="Kadiv"): ?>
										<i>Kepala Divisi</i>
										<?php else: ?>
										<div class="row">
											<div class="center">
												<i>&nbsp; &nbsp; User Biasa</i>
											</div>
										</div>
										<?php endif; ?>
									</td>
									<td>
										<a href="<?php echo e(url('edituser', [$key->id])); ?>"><i class="fa fa-edit" aria-hidden="true"> </i> Ubah Aksess</a>
									</td>
								</tr>
							</tbody>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					</div>
		<?php echo $user->render(); ?>

				</div>
			</div>
		</div>	
	</div>
</div>
<nav>
    <div class="nav-wrapper">
      <a href="/" class="brand-logo">&nbsp;Sucofindo</a>
      <ul id="nav-mobie le" class="right hide-on-med-and-down">
        <li><a href="<?php echo e(url('/allfile')); ?>">File</a></li>
        <li><a href="<?php echo e(url('/files')); ?>">Data Tanggung Jawab</a></li>
        <li><a href="<?php echo e(url('/members')); ?>">Data Anggota</a></li>

        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/login')); ?>">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display:none;">
            <?php echo e(csrf_field()); ?>

          </form>
        
      </ul>
    </div>
  </nav>
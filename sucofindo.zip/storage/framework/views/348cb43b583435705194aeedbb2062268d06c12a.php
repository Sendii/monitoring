<!DOCTYPE html>
<html>
<head>
</head>
<body class="hold-transition skin-blue sidebar-mini" background="github.png">
  <!-- Content Wrapper. Contains page content -->
<div class="row">
  <div class="content-wrapper">
  <div class="container-fluid spark-screen">
        <div class="row"><br>
            	        <div class="col-md-10">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
            </div>
            <!-- /.box-header -->
            <!-- form start -->
             <?php echo csrf_field(); ?>

             <div class="box-body">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Kode PJ</label>
                  <div class="col-sm-3">
                    <input type="text" name="kodePj" value=" <?php echo e(isset($bppjadd->kodePj) ? $bppjadd->kodePj : ''); ?> " class="form-control" placeholder="Kode PJ">
                  </div>
                  <label class="col-sm-2 control-label">No. Registrasi Umum</label>
                  <div class="col-sm-3">
                    <input type="text" name="noregisumum" value=" <?php echo e(isset($bppjadd->no_regis_umum) ? $bppjadd->no_regis_umum : ''); ?> " class="form-control" id="inputPassword3" placeholder="No. Regis Umum">
                </div>
                <div class="form-group">
                  
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Tgl. Registrasi Umum</label>
                  <div class="col-sm-3">
                    <input type="date" name="tglregisumum" value=" <?php echo e(isset($bppjadd->tgl_regis_umum) ? $bppjadd->tgl_regis_umum : ''); ?> " class="form-control" id="inputPassword3" placeholder="Tgl. Regis Umum">
                  </div>
                  <label class="col-sm-2 control-label">No. Ppbj</label>
                  <div class="col-sm-3">
                    <input type="text" name="nopbbj" value=" <?php echo e(isset($bppjadd->no_pbbj) ? $bppjadd->no_pbbj : ''); ?> " class="form-control" id="inputPassword3" placeholder="No. Ppbj">
                </div>
                <div class="form-group">
                  
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Tgl. Permintaan Ppbj</label>
                  <div class="col-sm-3">
                    <input type="date" name="tglpermintaanPpbj" value=" <?php echo e(isset($bppjadd->tgl_permintaan_Ppbj) ? $bppjadd->tgl_permintaan_Ppbj : ''); ?> " class="form-control" id="inputPassword3" placeholder="Tgl Permintaan Ppbj">
                  </div>
                <label class="col-sm-2 control-label">Tgl. Dibutuhkan Ppbj</label>
                  <div class="col-sm-3">
                    <input type="date" name="tgldibutuhkanPpbj" value=" <?php echo e(isset($bppjadd->tgl_dibutuhkan_Ppbj) ? $bppjadd->tgl_dibutuhkan_Ppbj : ''); ?> " class="form-control" id="inputPassword3" placeholder="Tgl Dibutuhkan center">
                </div>
                <div class="form-group">
                  
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Jenis Pengadaan</label>
                  <div class="col-sm-3">
                    <input type="text" name="jenispengadaan" value=" <?php echo e(isset($bppjadd->jenis_pengadaan) ? $bppjadd->jenis_pengadaan : ''); ?> " class="form-control" id="inputPassword3" placeholder="Jenis Pengadaan">
                  </div>
                 <label class="col-sm-2 control-label">Banyak Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="banyakbarang" value=" <?php echo e(isset($bppjadd->banyak_brg) ? $bppjadd->banyak_brg : ''); ?> " class="form-control" id="inputPassword3" placeholder="Banyak Barang">
                </div>
                <div class="form-group">
                 
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Nama Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="namabarang" value=" <?php echo e(isset($bppjadd->nama_barang) ? $bppjadd->nama_barang : ''); ?> " class="form-control" id="inputPassword3" placeholder="Nama Barang">
                  </div>
                  <label class="col-sm-2 control-label">Harga Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="hargabarang" value=" <?php echo e(isset($bppjadd->harga_brg) ? $bppjadd->harga_brg : ''); ?> " class="form-control" id="inputPassword3" placeholder="Harga Barang">
                </div>
                <div class="form-group">
                  
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Jumlah Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="jumlahbarang" value=" <?php echo e(isset($bppjadd->jumlah_brg) ? $bppjadd->jumlah_brg : ''); ?> " class="form-control" id="inputPassword3" placeholder="Jumlah Barang">
                  </div>
                  <label class="col-sm-2 control-label">Harga Total Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="hargatotalbarang" name=" <?php echo e(isset($bppjadd->hargatotal_brg) ? $bppjadd->hargatotal_brg : ''); ?> " class="form-control" id="inputPassword3" placeholder="Harga Total Barang">
                </div>
                <div class="form-group">
                  
                  </div><hr>
<button type="submit" name="simpan" class="btn btn-primary pull-right" style="margin-left:100" >Submit</button>
                </div>
        </div>
    </div>
  </div>
 <!-- Control Sidebar -->
</div>
</div>
</body>
</html>
<?php echo $__env->make('layouts.adminlte', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form class="form-horizontal" method="POST" action=" <?php echo e(route('updatePpbj')); ?> " >
	<input type="hidden" name="id" value="<?php echo e($editbarang->id); ?>">
	<input type="hidden" name="id_barang" value="<?php echo e($editbarang->id); ?>">
	<?php echo $__env->make('ppbj.formsedit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

	<script type="text/javascript">
		$(document).ready(function () {
			$('select').material_select();
		});
	</script>
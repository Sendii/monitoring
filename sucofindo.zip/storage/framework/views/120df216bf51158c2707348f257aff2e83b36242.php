<!DOCTYPE html>
<html class="nojs html css_verticalspacer" lang="en-US">
 <head>

  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
  <meta name="generator" content="2017.0.0.363"/>
  
  <script type="text/javascript">
   // Update the 'nojs'/'js' class on the html node
document.documentElement.className = document.documentElement.className.replace(/\bnojs\b/g, 'js');

// Check that all required assets are uploaded and up-to-date
if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["museutils.js", "museconfig.js", "jquery.musemenu.js", "jquery.musepolyfill.bgsize.js", "jquery.watch.js", "webpro.js", "jquery.scrolleffects.js", "require.js", "index.css"], "outOfDate":[]};
</script>
  
  <title>Home</title>
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="css/site_global.css?crc=443350757"/>
  <link rel="stylesheet" type="text/css" href="css/index.css?crc=251831644" id="pagesheet"/>
  <!-- IE-only CSS -->
  <!--[if lt IE 9]>
  <link rel="stylesheet" type="text/css" href="css/iefonts_index.css?crc=4068996755"/>
  <![endif]-->
  <!-- Other scripts -->
  <script type="text/javascript">
   var __adobewebfontsappname__ = "muse";
</script>
  <!-- JS includes -->
  <script type="text/javascript">
   document.write('\x3Cscript src="' + (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//webfonts.creativecloud.com/maven-pro:n5,n4:all.js" type="text/javascript">\x3C/script>');
</script>
  <!--[if lt IE 9]>
  <script src="scripts/html5shiv.js?crc=4241844378" type="text/javascript"></script>
  <![endif]-->
    <!--HTML Widget code-->
  
			<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
			<style>
				.fa-block:before, .fa-block {
					display: block;
				}
				#u332:hover .fa {
					color: #F25824;
				}
			</style>
		
			<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
			<style>
				.fa-block:before, .fa-block {
					display: block;
				}
				#u336:hover .fa {
					color: #F25824;
				}
			</style>
		
			<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
			<style>
				.fa-block:before, .fa-block {
					display: block;
				}
				#u341:hover .fa {
					color: #F25824;
				}
			</style>
		
 </head>
 <body>

  <div class="clearfix" id="page"><!-- column -->
   <div class="position_content" id="page_position_content">
    <div class="clearfix colelem" id="pu434-5"><!-- group -->
     <div class="clearfix grpelem" id="u434-5"><!-- content -->
      <p><span id="u434">Div</span><span id="u434-2">sum</span></p>
     </div>
     <nav class="MenuBar clearfix grpelem" id="menuu398"><!-- horizontal box -->
      <div class="MenuItemContainer clearfix grpelem" id="u413"><!-- vertical box -->
       <div class="MenuItem MenuItemWithSubMenu clearfix colelem" id="u416"><!-- horizontal box -->
        <div class="MenuItemLabel NoWrap clearfix grpelem" id="u418-4"><!-- content -->
         <p>WELCOME</p>
        </div>
       </div>
      </div>
      <div class="MenuItemContainer clearfix grpelem" id="u399"><!-- vertical box -->
       <div class="MenuItem MenuItemWithSubMenu clearfix colelem" id="u402"><!-- horizontal box -->
        <div class="MenuItemLabel NoWrap clearfix grpelem" id="u404-4"><!-- content -->
         <p>ABOUT</p>
        </div>
       </div>
      </div>
      <div class="MenuItemContainer clearfix grpelem" id="u427"><!-- vertical box -->
       <div class="MenuItem MenuItemWithSubMenu clearfix colelem" id="u428"><!-- horizontal box -->
        <div class="MenuItemLabel NoWrap clearfix grpelem" id="u430-4"><!-- content -->
         <p>MONITORING</p>
        </div>
       </div>
      </div>
      <div class="MenuItemContainer clearfix grpelem" id="u420"><!-- vertical box -->
       <div class="MenuItem MenuItemWithSubMenu clearfix colelem" id="u421"><!-- horizontal box -->
        <div class="MenuItemLabel NoWrap clearfix grpelem" id="u423-4"><!-- content -->
         <p>REPORT</p>
        </div>
       </div>
      </div>
      <div class="MenuItemContainer clearfix grpelem" id="u406"><!-- vertical box -->
       <div class="MenuItem MenuItemWithSubMenu clearfix colelem" id="u409"><!-- horizontal box -->
        <div class="MenuItemLabel NoWrap clearfix grpelem" id="u411-4"><!-- content -->
         <p>LOGOUT</p>
        </div>
       </div>
      </div>
     </nav>
    </div>
    <div class="browser_width colelem" id="u394-bw">
     <div class="museBGSize" id="u394"><!-- column -->
      <div class="clearfix" id="u394_align_to_page">
       <div class="clearfix colelem" id="u397-6"><!-- content -->
        <p>SELAMAT DATANG PADA WEBSITE</p>
        <p>DIVISI UMUM PT. SUCOFINDO</p>
       </div>
       <div class="clearfix colelem" id="u395-6"><!-- content -->
        <p>TEST TEST TEST TEST TEST TEST TEST TEST TEST TEST TEST</p>
        <p>TEST TEST TEST TEST TEST TEST TEST.</p>
       </div>
       <div class="rounded-corners clearfix colelem" id="u396-4"><!-- content -->
        <p>read more</p>
       </div>
      </div>
     </div>
    </div>
    <div class="browser_width colelem" id="u352-bw">
     <div id="u352"><!-- group -->
      <div class="clearfix" id="u352_align_to_page">
       <a class="nonblock nontext clearfix grpelem" id="u353-4" href="http://www.musefree.com"><!-- content --><p>sollicitudin libero</p></a>
      </div>
     </div>
    </div>
    <div class="clearfix colelem" id="pu354"><!-- group -->
     <div class="clearfix mse_pre_init" id="u354"><!-- column -->
      <div class="museBGSize rounded-corners colelem" id="u357"><!-- simple frame --></div>
      <div class="clearfix colelem" id="u356-4"><!-- content -->
       <p>Nulla elementum</p>
      </div>
      <div class="clearfix colelem" id="u355-4"><!-- content -->
       <p>Duis fringilla justo orci, ut pharetra lorem fermentum at. Morbi varius, nulla ac semper viverra, eros velit ultricies eros, sed commodo dui.</p>
      </div>
      <div class="rounded-corners clearfix colelem" id="u358-4"><!-- content -->
       <p>read more</p>
      </div>
     </div>
     <div class="clearfix mse_pre_init" id="u359"><!-- column -->
      <div class="museBGSize rounded-corners colelem" id="u360"><!-- simple frame --></div>
      <div class="clearfix colelem" id="u363-4"><!-- content -->
       <p>sollicitudin libero</p>
      </div>
      <div class="clearfix colelem" id="u361-4"><!-- content -->
       <p>Duis fringilla justo orci, ut pharetra lorem fermentum at. Morbi varius, nulla ac semper viverra, eros velit ultricies eros, sed commodo dui.</p>
      </div>
      <div class="rounded-corners clearfix colelem" id="u362-4"><!-- content -->
       <p>read more</p>
      </div>
     </div>
     <div class="clearfix mse_pre_init" id="u364"><!-- column -->
      <div class="museBGSize rounded-corners colelem" id="u368"><!-- simple frame --></div>
      <div class="clearfix colelem" id="u366-4"><!-- content -->
       <p>Duis consequat</p>
      </div>
      <div class="clearfix colelem" id="u365-4"><!-- content -->
       <p>Duis fringilla justo orci, ut pharetra lorem fermentum at. Morbi varius, nulla ac semper viverra, eros velit ultricies eros, sed commodo dui.</p>
      </div>
      <div class="rounded-corners clearfix colelem" id="u367-4"><!-- content -->
       <p>read more</p>
      </div>
     </div>
    </div>
    <div class="clearfix colelem" id="u322"><!-- column -->
     <div class="colelem" id="u325"><!-- simple frame --></div>
     <div class="colelem" id="u324"><!-- simple frame --></div>
     <div class="colelem" id="u323"><!-- simple frame --></div>
    </div>
    <div class="clearfix colelem" id="pu302"><!-- group -->
     <div class="clearfix grpelem" id="u302"><!-- column -->
      <a class="nonblock nontext clearfix colelem" id="u304-4" href="http://www.musefree.com"><!-- content --><p>sollicitudin libero</p></a>
      <div class="clearfix colelem" id="u303-4"><!-- content -->
       <p>Duis fringilla justo orci, ut pharetra lorem fermentum at. Morbi varius, nulla ac semper</p>
      </div>
     </div>
     <form class="form-grp clearfix grpelem" id="widgetu305" method="post" enctype="multipart/form-data" action="scripts/form-u305.php"><!-- none box -->
      <div class="fld-grp clearfix grpelem" id="widgetu316" data-required="true"><!-- none box -->
       <span class="fld-input NoWrap actAsDiv clearfix grpelem" id="u318-4"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu316_input" name="custom_U316" tabindex="1"/><label class="wrapped-input fld-prompt" id="widgetu316_prompt" for="widgetu316_input"><span class="actAsPara">Enter Name</span></label></span>
      </div>
      <div class="fld-grp clearfix grpelem" id="widgetu307" data-required="true" data-type="email"><!-- none box -->
       <span class="fld-input NoWrap actAsDiv clearfix grpelem" id="u310-4"><!-- content --><input class="wrapped-input" type="email" spellcheck="false" id="widgetu307_input" name="Email" tabindex="2"/><label class="wrapped-input fld-prompt" id="widgetu307_prompt" for="widgetu307_input"><span class="actAsPara">Enter Email</span></label></span>
      </div>
      <div class="clearfix grpelem" id="u311-4"><!-- content -->
       <p>Submitting Form...</p>
      </div>
      <div class="clearfix grpelem" id="u320-4"><!-- content -->
       <p>The server encountered an error.</p>
      </div>
      <div class="clearfix grpelem" id="u306-4"><!-- content -->
       <p>Form received.</p>
      </div>
      <button class="submit-btn NoWrap clearfix grpelem" id="u321-4" type="submit" value="Submit" tabindex="4"><!-- content -->
       <div style="margin-top:-15px;height:15px;">
        <p>Submit</p>
       </div>
      </button>
      <div class="fld-grp clearfix grpelem" id="widgetu312" data-required="false"><!-- none box -->
       <span class="fld-textarea actAsDiv clearfix grpelem" id="u314-4"><!-- content --><textarea class="wrapped-input" id="widgetu312_input" name="custom_U312" tabindex="3"></textarea><label class="wrapped-input fld-prompt" id="widgetu312_prompt" for="widgetu312_input"><span class="actAsPara">Enter Your Message</span></label></span>
      </div>
     </form>
    </div>
    <div class="clearfix colelem" id="pu330"><!-- group -->
     <div class="clearfix mse_pre_init" id="u330"><!-- group -->
      <div class="size_fixed grpelem" id="u332"><!-- custom html -->
       <i class="fa fa-cogs fa-block" style="line-height:66px;"></i>
      </div>
      <div class="clearfix grpelem" id="pu334-4"><!-- column -->
       <div class="clearfix colelem" id="u334-4"><!-- content -->
        <p>sollicitudin libero</p>
       </div>
       <div class="clearfix colelem" id="u331-4"><!-- content -->
        <p>Duis fringilla justo orci, ut pharetra lorem fermentum at. Morbi varius, nulla ac semper</p>
       </div>
      </div>
     </div>
     <div class="clearfix mse_pre_init" id="u335"><!-- group -->
      <div class="size_fixed grpelem" id="u336"><!-- custom html -->
       <i class="fa fa-comment fa-block" style="line-height:66px;"></i>
      </div>
      <div class="clearfix grpelem" id="pu338-4"><!-- column -->
       <div class="clearfix colelem" id="u338-4"><!-- content -->
        <p>sollicitudin libero</p>
       </div>
       <div class="clearfix colelem" id="u339-4"><!-- content -->
        <p>Duis fringilla justo orci, ut pharetra lorem fermentum at. Morbi varius, nulla ac semper</p>
       </div>
      </div>
     </div>
     <div class="clearfix mse_pre_init" id="u340"><!-- group -->
      <div class="size_fixed grpelem" id="u341"><!-- custom html -->
       <i class="fa fa-crop fa-block" style="line-height:66px;"></i>
      </div>
      <div class="clearfix grpelem" id="pu344-4"><!-- column -->
       <div class="clearfix colelem" id="u344-4"><!-- content -->
        <p>sollicitudin libero</p>
       </div>
       <div class="clearfix colelem" id="u343-4"><!-- content -->
        <p>Duis fringilla justo orci, ut pharetra lorem fermentum at. Morbi varius, nulla ac semper</p>
       </div>
      </div>
     </div>
    </div>
    <div class="clearfix colelem" id="u326"><!-- column -->
     <div class="colelem" id="u329" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-1,M12=0,M21=0,M22=-1,SizingMethod='auto expand')" data-mu-ie-matrix-dx="0" data-mu-ie-matrix-dy="0"><!-- simple frame --></div>
     <div class="colelem" id="u327" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-1,M12=0,M21=0,M22=-1,SizingMethod='auto expand')" data-mu-ie-matrix-dx="0" data-mu-ie-matrix-dy="0"><!-- simple frame --></div>
     <div class="colelem" id="u328" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-1,M12=0,M21=0,M22=-1,SizingMethod='auto expand')" data-mu-ie-matrix-dx="0" data-mu-ie-matrix-dy="0"><!-- simple frame --></div>
    </div>
    <div class="browser_width colelem" id="u201-bw">
     <div class="museBGSize" id="u201"><!-- simple frame --></div>
    </div>
    <div class="clearfix mse_pre_init" id="u202-4"><!-- content -->
     <p>Quisque a felis velgst nisl scelerisque ornare</p>
    </div>
    <div class="verticalspacer" data-offset-top="2075" data-content-above-spacer="2074" data-content-below-spacer="62"></div>
    <a class="nonblock nontext clearfix colelem" id="u203-6" href="http://www.musefree.com"><!-- content --><p>MADE WITH&nbsp; <span class="actAsInlineDiv normal_text" id="u204"><!-- content --><span class="actAsDiv clip_frame excludeFromNormalFlow" id="u205"><!-- image --><img id="u205_img" src="images/heart.png?crc=117585526" alt="" width="11" height="9"/></span></span>&nbsp; BY PT. SUCOFINDO</p></a>
   </div>
  </div>
  <!-- Other scripts -->
  <script type="text/javascript">
   window.Muse.assets.check=function(d){if(!window.Muse.assets.checked){window.Muse.assets.checked=!0;var b={},c=function(a,b){if(window.getComputedStyle){var c=window.getComputedStyle(a,null);return c&&c.getPropertyValue(b)||c&&c[b]||""}if(document.documentElement.currentStyle)return(c=a.currentStyle)&&c[b]||a.style&&a.style[b]||"";return""},a=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),
16);return 0},g=function(g){for(var f=document.getElementsByTagName("link"),h=0;h<f.length;h++)if("text/css"==f[h].type){var i=(f[h].href||"").match(/\/?css\/([\w\-]+\.css)\?crc=(\d+)/);if(!i||!i[1]||!i[2])break;b[i[1]]=i[2]}f=document.createElement("div");f.className="version";f.style.cssText="display:none; width:1px; height:1px;";document.getElementsByTagName("body")[0].appendChild(f);for(h=0;h<Muse.assets.required.length;){var i=Muse.assets.required[h],l=i.match(/([\w\-\.]+)\.(\w+)$/),k=l&&l[1]?
l[1]:null,l=l&&l[2]?l[2]:null;switch(l.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");f.className+=" "+k;k=a(c(f,"color"));l=a(c(f,"backgroundColor"));k!=0||l!=0?(Muse.assets.required.splice(h,1),"undefined"!=typeof b[i]&&(k!=b[i]>>>24||l!=(b[i]&16777215))&&Muse.assets.outOfDate.push(i)):h++;f.className="version";break;case "js":h++;break;default:throw Error("Unsupported file type: "+l);}}d?d().jquery!="1.8.3"&&Muse.assets.outOfDate.push("jquery-1.8.3.min.js"):Muse.assets.required.push("jquery-1.8.3.min.js");
f.parentNode.removeChild(f);if(Muse.assets.outOfDate.length||Muse.assets.required.length)f="Some files on the server may be missing or incorrect. Clear browser cache and try again. If the problem persists please contact website author.",g&&Muse.assets.outOfDate.length&&(f+="\nOut of date: "+Muse.assets.outOfDate.join(",")),g&&Muse.assets.required.length&&(f+="\nMissing: "+Muse.assets.required.join(",")),alert(f)};location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi)?setTimeout(function(){g(!0)},5E3):g()}};
var muse_init=function(){require.config({baseUrl:""});require(["jquery","museutils","whatinput","jquery.musemenu","jquery.musepolyfill.bgsize","jquery.watch","webpro","jquery.scrolleffects"],function(d){var $ = d;$(document).ready(function(){try{
window.Muse.assets.check($);/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
Muse.Utils.resizeHeight('.browser_width');/* resize height */
Muse.Utils.requestAnimationFrame(function() { $('body').addClass('initialized'); });/* mark body as initialized */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.initWidget('.MenuBar', ['#bp_infinity'], function(elem) { return $(elem).museMenu(); });/* unifiedNavBar */
Muse.Utils.initWidget('#widgetu305', ['#bp_infinity'], function(elem) { return new WebPro.Widget.Form(elem, {validationEvent:'submit',errorStateSensitivity:'high',fieldWrapperClass:'fld-grp',formSubmittedClass:'frm-sub-st',formErrorClass:'frm-subm-err-st',formDeliveredClass:'frm-subm-ok-st',notEmptyClass:'non-empty-st',focusClass:'focus-st',invalidClass:'fld-err-st',requiredClass:'fld-err-st',ajaxSubmit:true}); });/* #widgetu305 */
$('#u394').registerBackgroundPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-20.3]},{"speed":[0,0],"in":[-20.3,Infinity]}]);/* scroll effect */
$('#u354').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,577.35]},{"speed":[1,1],"in":[577.35,Infinity]}]);/* scroll effect */
$('#u359').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,577.35]},{"speed":[-1,1],"in":[577.35,Infinity]}]);/* scroll effect */
$('#u364').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,577.35]},{"speed":[0,2],"in":[577.35,Infinity]}]);/* scroll effect */
$('#u330').registerPositionScrollEffect([{"speed":[-1,1],"in":[-Infinity,759.75]},{"speed":[0,1],"in":[759.75,Infinity]}]);/* scroll effect */
$('#u335').registerPositionScrollEffect([{"speed":[-1,1],"in":[-Infinity,1020]},{"speed":[0,1],"in":[1020,Infinity]}]);/* scroll effect */
$('#u340').registerPositionScrollEffect([{"speed":[-1,1],"in":[-Infinity,890]},{"speed":[0,1],"in":[890,Infinity]}]);/* scroll effect */
$('#u201').registerBackgroundPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,1791.65]},{"speed":[0,0],"in":[1791.65,Infinity]}]);/* scroll effect */
$('#u202-4').registerPositionScrollEffect([{"speed":[-1,1],"in":[-Infinity,1255.9]},{"speed":[0,1],"in":[1255.9,Infinity]}]);/* scroll effect */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
}catch(b){if(b&&"function"==typeof b.notify?b.notify():Muse.Assert.fail("Error calling selector function: "+b),false)throw b;}})})};

</script>
  <!-- RequireJS script -->
  <script src="scripts/require.js?crc=244322403" type="text/javascript" async data-main="scripts/museconfig.js?crc=168988563" onload="if (requirejs) requirejs.onError = function(requireType, requireModule) { if (requireType && requireType.toString && requireType.toString().indexOf && 0 <= requireType.toString().indexOf('#scripterror')) window.Muse.assets.check(); }" onerror="window.Muse.assets.check();"></script>
   </body>
</html>

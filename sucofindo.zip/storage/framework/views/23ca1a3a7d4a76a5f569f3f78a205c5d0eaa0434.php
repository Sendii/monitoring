<!-- Left side column. contains the logo and sidebar -->
<body class="hold-transition skin-blue sidebar-mini">
        <script src="../../js/adminlte.min.js"></script>
</body>

<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <?php if(! Auth::guest()): ?>
            <div class="user-panel">
                <div class="pull-left image">
                    <img style="width:60px; height:60px; margin-right: 25px;" src="/uploads/avatar/defaults.jpg" class="img-circle" alt="User Image" />
                </div>
                <div class="pull-left info">
                    <p><?php echo e(Auth::user()->name); ?></p>
                    <!-- Status -->
                    <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(trans('adminlte_lang::message.online')); ?></a><br>
                </div>
            </div>
        <?php endif; ?>

        <!-- search form (Optional) -->
        
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu">


            <li class="header">Inventory</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="active"><a href="<?php echo e(url('/home')); ?>"><i class='fa fa-dashboard'></i> <span>Halaman Utama</span></a></li>
            <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i> <span>Lihat Data</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="display: none;">
            <li class="treeview">
              <a href=" <?php echo e(url('/kelas')); ?> "><i class="fa fa-magic"></i> Kelas
                <span class="pull-right-container">
                </span>
              </a>
            </li>
            <li class="treeview">
              <a href=" <?php echo e(url('/siswa')); ?> "><i class="fa fa-user"></i> Siswa
                <span class="pull-right-container">
                </span>
              </a>
            </li>
          <li class="treeview">
              <a href=" <?php echo e(url('/barang')); ?> "><i class="fa fa-gear"></i> Barang
                <span class="pull-right-container">
                </span>
              </a>
            </li>
            <li class="treeview">
              <a href=" <?php echo e(url('/peminjam')); ?> "><i class="fa fa-book"></i> Peminjam
                <span class="pull-right-container">
                </span>
              </a>
            </li>
          </ul>
        </li>
      <!--TAMBAH -->
      <li class="treeview">
          <a href="#">
            <i class="fa fa-plus"></i> <span>Tambah Data</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="display: none;">
            <li class="treeview">
              <a href=" <?php echo e(url('/kelas/tambah')); ?> "><i class="fa fa-magic"></i>Data Kelas
                <span class="pull-right-container">
                </span>
              </a>
            </li>
            <li class="treeview">
              <a href=" <?php echo e(url('/siswa/tambah')); ?> "><i class="fa fa-user"></i>Data Siswa
                <span class="pull-right-container">
                </span>
              </a>
            </li>
            <li class="treeview">
              <a href=" <?php echo e(url('/barang/tambah')); ?> "><i class="fa fa-gear"></i> Data Barang
                <span class="pull-right-container">
                </span>
              </a>
            </li>
          </ul>
        </li>
            <li><a href="<?php echo e(url('/barang/pinjam')); ?>"><i class='fa fa-edit'></i> <span>Pinjam Barang</span></a></li>
            <li class="treeview">
          <a href="#">
            <i class="fa fa-folder-open"></i> <span>PDF</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="display: none;">
                      <li class="treeview">
              <a href="#"><i class="fa fa-magic"></i> Kelas
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu" style="display: none;">
                <li class="treeview">
                  <a href="#"><i class="fa fa-share"></i> Opsi/Pilihan
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu" style="display: none;">
                    <li><a href="<?php echo e('/pdf/viewall/kelas'); ?>"><i class="fa fa-book"></i> Lihat PDF</a></li>
                    <li><a href=" <?php echo e('/kelas/downloadPdf/'); ?> "><i class="fa fa-download"></i> Download PDF</a></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-user"></i> Siswa
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu" style="display: none;">
                <li class="treeview">
                  <a href="#"><i class="fa fa-share"></i> Opsi/Pilihan
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu" style="display: none;">
                    <li><a href="<?php echo e('/pdf/viewall/siswa'); ?>"><i class="fa fa-book"></i> Lihat PDF</a></li>
                    <li><a href=" <?php echo e('/siswaa/downloadPdf/'); ?> "><i class="fa fa-download"></i> Download PDF</a></li>
                  </ul>
                </li>
              </ul>
            </li>

          <li class="treeview">
              <a href="#"><i class="fa fa-gear"></i> Barang
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu" style="display: none;">
                <li class="treeview">
                  <a href="#"><i class="fa fa-share"></i> Opsi/Pilihan
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu" style="display: none;">
                    <li><a href="<?php echo e('/pdf/viewall/barang'); ?>"><i class="fa fa-book"></i> Lihat PDF</a></li>
                    <li><a href=" <?php echo e('/barang/downloadPdf/'); ?> "><i class="fa fa-download"></i> Download PDF</a></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-book"></i> Peminjam
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu" style="display: none;">
                <li class="treeview">
                  <a href="#"><i class="fa fa-share"></i> Opsi/Pilihan
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu" style="display: none;">
                    <li><a href=" <?php echo e('/pdf/viewall/peminjam'); ?> "><i class="fa fa-book"></i> Lihat PDF</a></li>
                    <li><a href=" <?php echo e('/peminjam/downloadPdf/'); ?> "><i class="fa fa-download"></i> Download PDF</a></li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
        </li>    
<!--             <li class="treeview">
                <a href="#"><i class='fa fa-download'></i> <span>Download Data (PDF)</span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href=" <?php echo e('/barang/downloadPdf'); ?> ">Data Barang</a></li>
                    <li><a href=" <?php echo e('/pdf/downloads/siswa'); ?> ">Data Siswa</a></li>
                    <li><a href=" <?php echo e('/pdf/downloads/siswa'); ?> ">Data Kelas</a></li>
                </ul>
            </li>
 -->        </ul><!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>

<!DOCTYPE html>
<html lang="id">
<head>
</head>
<body class="hold-transition skin-blue sidebar-mini" background="github.png">
  <section class="content" style="background-color: #ecf0f5;">
    <div class="row">
      <div class="content-wrapper">
        <div class="container-fluid spark-screen">
          <div class="row"><br>
            <div class="col-md-12">
              <!-- Horizontal Form -->
              <div class="box box-info">
                <center><h2>Penugasan Data Ppbj</h2> </center>
                <div class="box-header with-border">
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo csrf_field(); ?>

                <div class="box-body">
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">Kode PJ</label>
                    <div class="col-sm-2">
                      <input type="text" name="kodePj" value=" <?php echo e(isset($ppbjassignmentEdit->kodePj) ? $ppbjassignmentEdit->kodePj : ''); ?> " class="form-control" placeholder="Kode PJ" readonly>
                      <input type="hidden" name="id">
                    </div>
                    <label class="col-sm-2 control-label">No. Registrasi Umum</label>
                    <div class="col-sm-2">
                      <input type="text" name="noregisumum" value=" <?php echo e(isset($ppbjassignmentEdit->no_regis_umum) ? $ppbjassignmentEdit->no_regis_umum : ''); ?> " class="form-control" id="inputPassword3" placeholder="No. Regis Umum" readonly>
                    </div>
                    <label class="col-sm-1 control-label">No. Ppbj</label>
                    <div class="col-sm-2">
                      <input type="text" name="noppbj" value=" <?php echo e(isset($ppbjassignmentEdit->no_ppbj) ? $ppbjassignmentEdit->no_ppbj : ''); ?> " class="form-control" id="inputPassword3" placeholder="No. Ppbj" readonly>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Tgl. Registrasi Umum</label>
                    <div class="col-sm-2">
                      <input type="date" name="tglregisumum" value=" <?php echo e($ppbjassignmentEdit->tgl_regis_umum); ?> " class="form-control" id="inputPassword3" placeholder="Tgl. Regis Umum">
                    </div>
                    <label class="col-sm-2 control-label">Tgl. Permintaan Ppbj</label>
                    <div class="col-sm-2">
                      <input type="date" name="tglpermintaanppbj" value=" <?php echo e(isset($ppbjassignmentEdit->tgl_permintaan_ppbj) ? $ppbjassignmentEdit->tgl_permintaan_ppbj : ''); ?> " class="form-control" id="inputPassword3" placeholder="Tgl Permintaan Ppbj">
                    </div>
                    <label class="col-sm-1 control-label">Tgl. Dibutuhkan</label>
                    <div class="col-sm-2">
                      <input type="date" name="tgldibutuhkanppbj" value=" <?php echo e(isset($ppbjassignmentEdit->tgl_dibutuhkan_ppbj) ? $ppbjassignmentEdit->tgl_dibutuhkan_ppbj : ''); ?> " class="form-control" id="inputPassword3" placeholder="Tgl Dibutuhkan center">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Jenis Pengadaan</label>
                    <div class="col-sm-3">
                      <select name="jenispengadaan" class="form-control select2 select2-hidden-accessibles" style="width:100%;" tabindex="-1" aria-hidden="true">
                        <?php $__currentLoopData = $pengadaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option selected value="<?php echo e($key->id_pengadaan); ?>">
                          <?php echo e($key->namapengadaan); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>                      
                    </div>
                    <label class="col-sm-2 control-label">Unit Kerja</label>
                    <div class="col-sm-3">
                     <select name="id_unit" class="form-control select2 select2-hidden-accessibles" style="width:100%;" tabindex="-1" aria-hidden="true" readonly>
                      <?php $__currentLoopData = $unitkerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                      <option value="<?php echo e($key->id_unit); ?>" <?php echo e($ppbjassignmentEdit->id_unit == $key->id_unit ? 'selected' : ''); ?> >
                        <?php echo e($key->aa); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Banyak Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="banyakbarang" value=" <?php echo e(isset($ppbjassignmentEdit->banyak_brg) ? $ppbjassignmentEdit->banyak_brg : ''); ?> " class="form-control" id="inputPassword3" placeholder="Banyak Barang" readonly>
                  </div>
                  <label class="col-sm-2 control-label">Nama Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="namabarang" value=" <?php echo e(isset($ppbjassignmentEdit->nama_barang) ? $ppbjassignmentEdit->nama_barang : ''); ?> " class="form-control" id="inputPassword3" placeholder="Nama Barang" readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Jumlah Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="jumlahbarang" value=" <?php echo e(isset($ppbjassignmentEdit->jumlah_brg) ? $ppbjassignmentEdit->jumlah_brg : ''); ?> " class="form-control" id="inputPassword3" placeholder="Jumlah Barang" readonly>
                  </div>
                  <label class="col-sm-2 control-label">Harga Barang</label>
                  <div class="col-sm-3">
                    <input type="text" name="hargabarang" value=" <?php echo e(isset($ppbjassignmentEdit->harga_brg) ? $ppbjassignmentEdit->harga_brg : ''); ?> " class="form-control" id="inputPassword3" placeholder="Harga Barang" readonly>
                  </div>
                </div><hr>

                <!-- Penugasan dari Kasubag Ke Pegawai Utk Memonitoring ke Kepala Divisi -->
                <div class="form-group">
                  <label class="col-sm-2 control-label">Pemekerja</label>
                  <div class="col-sm-3">
                   <select name="id_pegawai" class="form-control select2 select2-hidden-accessibles" style="width:100%;" tabindex="-1" aria-hidden="true" value="<?php echo e($ppbjassignmentEdit->id_pegawai); ?>" >
                    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                    <option <?php echo e($ppbjassignmentEdit->id_pegawai == $key->id_pegawai ? 'selected' : ''); ?> value="<?php echo e($key->id_pegawai); ?>">
                      <?php echo e($key->namapegawai); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Tgl. Spph</label>
                <div class="col-sm-3">
                  <input type="date" name="p_tglspph" class="form-control" id="inputPassword3" placeholder="Tgl. Regis Umum">
                </div>
                <label class="col-sm-2 control-label">No. Spph</label>
                <div class="col-sm-2">
                  <input type="text" name="p_nospph" value=" <?php echo e(isset($prosespengadaan->no_spph) ? $prosespengadaan->no_spph : ''); ?> " class="form-control" id="inputPassword3" placeholder="No. Ppbj">
                </div>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label">Tgl. Etp</label>
              <div class="col-sm-3">
                <input type="date" name="p_tgletp" class="form-control" id="inputPassword3" placeholder="Tgl. Regis Umum">
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label">Tgl. Pengumuman</label>
              <div class="col-sm-3">
                <input type="date" name="p_tglpmn" class="form-control" id="inputPassword3" placeholder="Tgl. Regis Umum">
              </div>
              <label class="col-sm-2 control-label">No. Pengumuman</label>
              <div class="col-sm-3">
                <input type="text" name="p_nopmn" class="form-control" id="inputPassword3" placeholder="No. Ppbj">
              </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">Tgl. Kontrak</label>
                <div class="col-sm-3">
                  <input type="date" name="p_tglkon" class="form-control" id="inputPassword3" placeholder="Tgl. Regis Umum">
                </div>
                <label class="col-sm-2 control-label">No. Kontrak</label>
                    <div class="col-sm-3">
                      <input type="text" name="p_nokon" class="form-control" id="inputPassword3" placeholder="No. Ppbj">
                    </div>
                  </div>
              </div>
          </div>
          <div class="box-footer">
            <button type="submit" name="simpan" class="btn btn-primary pull-right">>&nbsp;Tambahkan</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</section>
</body>
</html>
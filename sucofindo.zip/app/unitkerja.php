<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class unitkerja extends Model
{
    //
}

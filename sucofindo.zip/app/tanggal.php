<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tanggal extends Model
{
    //
}

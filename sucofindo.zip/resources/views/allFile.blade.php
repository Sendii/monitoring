	@extends('layouts.app')

@section('title') CRUD Laravel - Data Kelas @endsection

@section('content')


@endsection